package alexiil.mc.mod.pipes.blocks;

@Deprecated
public interface BlockPipeItem {}

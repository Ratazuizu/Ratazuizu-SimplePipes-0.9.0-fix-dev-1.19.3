# SimplePipes

This is a test pipe implementation mod using the [LibBlockAttributes](https://github.com/AlexIIL/LibBlockAttributes) API, for the [Fabric](https://fabricmc.net/) API, based around [Minecraft](https://minecraft.net).

This is (in most cases) a straight port of a tiny subset of [BuildCraft's](https://www.mod-buildcraft.com) transport pipes.
